<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        /* .outer-container {
            position : absolute;
            display: table;
            width: 40%; /* This could be ANY width 
            height: 40%; /* This could be ANY height 
            background: #ccc;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
        }

        .inner-container {
            display: table-cell;
            vertical-align: middle;
            text-align: center;
        }

       
        input[type=text],input[type=password]{
            border:1px solid grey;
        } */
        .centered-content {
            display: block;
            text-align: center;
           
            padding : 0px;
            
            margin:15px;
        }
        #mydiv {
            position:fixed;
            top: 50%;
            left: 50%;
            width:30em;
            height:18em;
            margin-top: -9em; /*set to a negative number 1/2 of your height*/
            margin-left: -15em; /*set to a negative number 1/2 of your width*/
            border: 1px solid #ccc;
            background-color: #f3f3f3;
        }
        .topmargin{
            height:50px;
            color:red;
            padding:15px;
        }
        input{
            height:20px;
            width:250px;
        }
    </style>
</head>
<body>
    
    <div id="mydiv" class="centered-content">
        
        <form action="<?php echo base_url();?>webadmin/LoginOut/checklogin" method="POST">
            <div class="topmargin">
                <code>
                    <?php 
                    if(isset($invalidcredentials)){
                        echo $invalidcredentials;
                    }
                    ?>
                </code>
            </div>
            <div class="centered-content">
                <input type="text" name="username" placeholder="username">
            </div>
            <div class="centered-content">
                <input type="password" name="password" placeholder="password">
            </div>
            <div class="centered-content">
                <input type="submit" value="Submit">
            </div>
        </form>
        
    </div>
    
   
    
</body>
</html>