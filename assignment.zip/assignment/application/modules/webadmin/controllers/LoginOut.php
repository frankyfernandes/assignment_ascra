<?php
    class LoginOut extends MYNOSES_Controller{
        function __construct(){
            parent::__construct();
            $this->load->helper('form');
        }
        public function index(){
            //echo "inside function ".__FUNCTION__;
           $this->session->sess_destroy(); 
           $this->load->view('Login');
        }

        

        

        public function checklogin(){
           /* echo  $username = $this->input->post('username');
           echo  $password = $this->input->post('password');
 */
           $this->load->model('Login');
            $username = $this->input->post('username');
            $password = hash('SHA512',$this->input->post('password'));
            $returned_data = $this->Login->checkuser($username,$password);
            if($returned_data != false){
                $data = $returned_data[0];
                //print_r($data);
                
                $this->session->set_userdata($data);
                redirect(base_url()."dashboard/Dashboard/showdashboard");
            }else{
                //invalid credentials
                $data['invalidcredentials'] = 'Username or password do not match';
                $this->load->view('webadmin/Login',$data);
            }
        }

        public function logout(){
            $this->session->sess_destroy();
            redirect(base_url());
        }
    }
?>