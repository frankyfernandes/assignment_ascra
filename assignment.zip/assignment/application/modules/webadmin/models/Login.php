<?php
    class Login extends CI_Model{
        public function index(){

        }

        public function checkuser($username,$password){
            $this->db->select('userid,username,email');
            $this->db->where("username",$username);
            $this->db->where("password",$password);
            $result = $this->db->get("users");
            if(sizeof($result->result_array($result) == 1)){
                return $result->result_array($result);
            }else{
                return false;
            }

        }
    }
?>