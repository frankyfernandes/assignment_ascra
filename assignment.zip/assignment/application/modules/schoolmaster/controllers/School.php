<?php
    class School extends MY_Controller{

        function __construct(){
            parent::__construct();
        }

        public function index(){
            $this->view();
        }

        public function view(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer');
        }

        public function create(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer'); 
        }

        public function store(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer'); 
        }

        public function edit(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer'); 
        }

        public function update(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer'); 
        }

        public function delete(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Schoolview');
            $this->load->view('common/Sidebar_footer'); 
        }
    }
    //index,create,store,edit,update,delete,view
?>
