<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Simple Sidebar - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo asset_url();?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo asset_url();?>css/simple-sidebar.css" rel="stylesheet">
    
    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo asset_url();?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo asset_url();?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo asset_url();?>vendor/angularjs/1.6.9/angular.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>
    <style>
        #menu-toggle{
            /*display: none; /* Hidden by default */
           /* position: fixed; /* Fixed/sticky position */
            bottom: 20px !important; /* Place the button at the bottom of the page */
            left: 250px; /* Place the button 30px from the right */
            z-index: 99; /* Make sure it does not overlap */
            border: none; /* Remove borders */
            outline: none; /* Remove outline */
            background: rgba(10,10,10,0.3) !important; /* Set a background color */
            color: white; /* Text color */
            cursor: pointer; /* Add a mouse pointer on hover */
            padding: 5px; /* Some padding */
            border-radius: 0px; /* Rounded corners */
            font-size: 18px; /* Increase font size */
        }

        .top-buffer { margin-top:20px; }
        .dropdown-menu-custom-color{
            background: #000;
        }
    </style>
</head>

<body>

    <div id="wrapper" class="toggled">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Assignment
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>dashboard/Dashboard/">Dashboard</a>
                </li>
               
                <!--li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Exams
                    <span class="caret"></span></a>
                    <ul class="dropdown-menu dropdown-menu-custom-color">
                    <li><a href="<?php echo base_url();?>exam/Exams/loadexampage/Showexams">Show Exams</a></li>
                    <li><a href="<?php echo base_url();?>exam/Exams/loadexampage/Addexam">Add Exam</a></li>
                    <li><a href="<?php echo base_url();?>exam/Exams/loadexampage/Modifyexam">Modify Exam</a></li>
                    </ul>
                </li>
                
                <li>
                    <a href="<?php echo base_url();?>addrole/Addrole">Add role</a>
                </li>
                <li>
                    <a href="<?php echo base_url()?>angularrouting/Routing">Angular Routing</a>
                </li>
                <li>
                    <a href="#">About</a>
                </li>
                <li>
                    <a href="#">Services</a>
                </li>
                <li>
                    <a href="#">Contact</a>
                </li-->
                <li>
                <a href="<?php echo base_url()?>schoolmaster/School">School Master</a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>webadmin/Loginout/logout">Logout</a>
                </li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            