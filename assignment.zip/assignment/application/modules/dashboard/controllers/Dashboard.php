<?php
    class Dashboard extends MY_Controller{

        function __construct(){
            parent::__construct();
        }

        public function index(){
            $this->showdashboard();
        }

        public function showdashboard(){
            $this->load->view('common/Sidebar_header');
            $this->load->view('Dashboardview');
            $this->load->view('common/Sidebar_footer');
        }
    }
?>