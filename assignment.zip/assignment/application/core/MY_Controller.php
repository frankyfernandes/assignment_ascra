<?php
    class MY_Controller extends MYNOSES_Controller{
        function __construct(){
            parent::__construct();
           
        //    echo $pageurl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        //    echo "<br>";
        //     echo $logouturl = base_url()."loginout/Loginout/logout";
        //    if($pageurl != $logouturl){
        //        echo "not same";
               
        //    }else{
        //        $this->session->sess_destroy;
        //    }

           $this->check_session();
           //$this->sidebar(); 
               // 
           
        }
        
        public function check_session(){
            if(!$this->session->has_userdata('username')){
               // redirect(base_url()."loginout/Loginout/logout");
               $this->logout();
            }
        }

        public function sidebar(){
            $this->load->view('Common/Sidebar.php');
        }

        public function logout(){
            $pageurl = '//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $homepageurl = base_url()."webadmin/LoginOut";
            
                $this->session->sess_destroy();
                //redirect(base_url()."home/Home");
                //if($pageurl != $homepageurl){
                    //echo "User not logged in. Please click <a href='".base_url()."home/Home'>here</a> to login.";
                    redirect($homepageurl);
                //}
            
            
        }
    }
?>