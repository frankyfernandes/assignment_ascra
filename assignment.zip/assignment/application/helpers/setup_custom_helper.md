I have this setup:

application
assets
system
.htaccess
and in the "assets" folder i have subfolders like "img" or "js" and so on. I also use "utility helper" to help me point to that folder.

If you want to try it, you have to first create a helper named "utility_helper.php" with this code:

     <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

     if ( ! function_exists('asset_url()'))
     {
       function asset_url()
       {
          return base_url().'assets/';
       }
     }
and store it in

     application/helpers/
then you have to autoload that helper, you go to:

  application/config/autoload.php
and auto load the helper (example: )

  $autoload['helper'] = array('form', 'url', 'utility');
you have also to route to that folder ('application/config/routes.php')

       $route['assets/(:any)'] = 'assets/$1';
and have a .htaccess file with this content:

    RewriteEngine on
    RewriteCond $1 !^(index\.php|images|assets|robots\.txt)
    RewriteRule ^(.*)$ /index.php/$1 [L]
now you can simply include external scripts, css example:

   <link rel="stylesheet" type="text/css" href="<?php echo asset_url();?>css/style.css">
where css is the folder inside assets and style.css is the css file. Like so:

   application
   assets
          css
              style.css
   system