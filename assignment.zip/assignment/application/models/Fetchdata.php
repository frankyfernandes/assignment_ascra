<?php
    class Fetchdata extends CI_Model{
        public function index(){

        }

        public function fetch(){
            $result = $this->db->query('select FLD_USERNAME,FLD_EMAIL from tbl_admin_login_master;');
            return $result->result_array();
        }
    }
?>